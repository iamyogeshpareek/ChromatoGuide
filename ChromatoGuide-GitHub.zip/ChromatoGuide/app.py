from __future__ import annotations

import sys
import json
from pathlib import Path
from datetime import date, datetime, timezone
from uuid import uuid4

import pandas as pd
import streamlit as st

sys.path.insert(0, str(Path(__file__).parent / "src"))
from hplc_copilot.engine import (Descriptors, adaptive_next, analyze_chromatogram,
    box_behnken_3factor, from_smiles, green_metrics, pareto_rows, recommend,
    route_summary, system_suitability, troubleshooting_guidance)

st.set_page_config(page_title="ChromatoGuide | HPLC Method Development", layout="wide")
st.title("ChromatoGuide")
st.caption("Chemistry-informed HPLC screening and method development")

if "runs" not in st.session_state:
    st.session_state.runs = []
if "study_id" not in st.session_state:
    st.session_state.study_id = str(uuid4())
    st.session_state.study_created_at_utc = datetime.now(timezone.utc).isoformat()
if "suitability_log" not in st.session_state:
    st.session_state.suitability_log = []
with st.sidebar:
    st.subheader("Study file")
    uploaded_project = st.file_uploader("Open saved study (.json)", type=["json"], key="project_upload")
    if st.button("Load study", disabled=uploaded_project is None):
        try:
            payload = json.loads(uploaded_project.getvalue().decode("utf-8"))
            if (not isinstance(payload, dict) or payload.get("schema_version") != 1 or
                    not isinstance(payload.get("config"), dict) or not isinstance(payload.get("runs"), list) or
                    any(not isinstance(row, dict) or row.get("route") not in {"Conventional DoE", "Adaptive optimization"} for row in payload.get("runs", []))):
                raise ValueError("Unsupported or invalid study file.")
            cfg = payload.get("config", {})
            for key, value in cfg.items():
                st.session_state[key] = value
            st.session_state.runs = payload["runs"]
            st.session_state.study_id = payload.get("study", {}).get("id", str(uuid4()))
            st.session_state.latest_chromatogram = payload.get("chromatogram_analysis")
            st.session_state.suitability_log = payload.get("suitability_log", [])
            st.session_state.latest_suitability = payload.get("latest_suitability")
            st.session_state.study_created_at_utc = payload.get("study", {}).get("created_at_utc", datetime.now(timezone.utc).isoformat())
            st.session_state.loaded_project_name = payload.get("study", {}).get("title", "Loaded study")
            st.success(f"Loaded {st.session_state.loaded_project_name} with {len(st.session_state.runs)} recorded runs.")
        except (ValueError, UnicodeDecodeError) as exc:
            st.error(f"Could not load study: {exc}")

tabchem, tab1, tab2, tab3, tab4, tab5, tab6, tab7 = st.tabs([
    "Analyte chemistry", "Chromatogram", "System suitability", "AQbD / DoE",
    "Green method", "Adaptive experiments", "Troubleshooting", "R&D workspace"])
with tabchem:
    left, right = st.columns([1, 1])
    with left:
        locked_analyte = bool(st.session_state.runs)
        name = st.text_input("Analyte name (label only)", placeholder="e.g., compound or project identifier", key="analyte_name", disabled=locked_analyte)
        smiles = st.text_input("SMILES (optional)", placeholder="Paste a canonical or isomeric SMILES", key="smiles", disabled=locked_analyte)
        supplied = None
        if smiles:
            calculated, message = from_smiles(smiles)
            if message:
                st.warning(message)
            else:
                supplied = calculated
                if st.session_state.get("descriptor_smiles_applied") != smiles:
                    st.session_state["descriptor_mw"] = float(calculated.molecular_weight)
                    st.session_state["descriptor_logp"] = float(calculated.clogp)
                    st.session_state["descriptor_tpsa"] = float(calculated.tpsa)
                    st.session_state["descriptor_hbd"] = int(calculated.hbd)
                    st.session_state["descriptor_hba"] = int(calculated.hba)
                    st.session_state["descriptor_charge"] = int(calculated.formal_charge)
                    st.session_state["descriptor_smiles_applied"] = smiles
        if supplied:
            st.success("2D descriptors calculated from SMILES with RDKit. These are not pKa or solubility predictions.")
        st.markdown("**Enter descriptors manually when known**")
        mw = st.number_input("Molecular weight (g/mol)", min_value=0.0, max_value=5000.0, value=float(supplied.molecular_weight if supplied else 300), step=1.0, key="descriptor_mw", disabled=locked_analyte)
        logp = st.number_input("cLogP", min_value=-20.0, max_value=20.0, value=float(supplied.clogp if supplied else 1), step=0.1, key="descriptor_logp", disabled=locked_analyte)
        tpsa = st.number_input("TPSA (Å²)", min_value=0.0, max_value=1000.0, value=float(supplied.tpsa if supplied else 50), step=1.0, key="descriptor_tpsa", disabled=locked_analyte)
        hbd = st.number_input("H-bond donors", min_value=0, max_value=100, value=int(supplied.hbd if supplied else 1), key="descriptor_hbd", disabled=locked_analyte)
        hba = st.number_input("H-bond acceptors", min_value=0, max_value=100, value=int(supplied.hba if supplied else 3), key="descriptor_hba", disabled=locked_analyte)
        charge = st.number_input("Formal charge from structure (if known)", min_value=-20, max_value=20, value=int(supplied.formal_charge if supplied else 0), key="descriptor_charge", disabled=locked_analyte)
        pka = st.selectbox("Ionization information", ["Unknown / not supplied", "Acidic (pKa known)", "Basic (pKa known)", "Amphoteric / multiple pKa"], key="descriptor_ionization", disabled=locked_analyte)
        st.caption("Name lookup, pKa, logD, solubility, and tautomer/protomer prediction are not included. Supply reliable values from a trusted source when available.")
    d = Descriptors(mw, logp, tpsa, hbd, hba, charge)
    with right:
        st.subheader("Descriptor summary")
        st.dataframe(pd.DataFrame([{"MW": mw, "cLogP": logp, "TPSA": tpsa, "HBD": hbd, "HBA": hba, "Formal charge": charge}]), hide_index=True, use_container_width=True)
        st.subheader("Screening hypotheses")
        for rank, item in enumerate(recommend(d, pka), start=1):
            with st.expander(f"{rank}. {item['mode']} · heuristic score {item['score']}", expanded=(rank == 1)):
                for reason in item["rationale"]:
                    st.write(f"• {reason}")
                st.markdown("**Candidate stationary-phase chemistries to investigate**")
                for col, rationale in item["columns"]:
                    st.write(f"**{col}:** {rationale}")
        st.caption("Scores are transparent rules over broad 2D descriptors, not a trained retention model. Confirm ionization at working pH, solubility, analyte stability, and column compatibility experimentally.")

with tab1:
    st.subheader("Chromatogram analyzer")
    st.write("Upload a two-column CSV with monotonically increasing time and detector response. The analyzer reports candidate peaks for review; it is not a validated integration package.")
    trace_file = st.file_uploader("Chromatogram CSV", type=["csv"], key="chromatogram_csv")
    if trace_file is not None:
        try:
            trace = pd.read_csv(trace_file)
            numeric_cols = [col for col in trace.columns if pd.to_numeric(trace[col], errors="coerce").notna().sum() >= 5]
            if len(numeric_cols) < 2:
                st.error("The CSV needs at least two numeric columns: time and detector response.")
            else:
                ca, cb, cc, cd = st.columns(4)
                time_col = ca.selectbox("Time column", numeric_cols, key="trace_time_col")
                signal_default = 1 if len(numeric_cols) > 1 else 0
                signal_col = cb.selectbox("Signal column", numeric_cols, index=signal_default, key="trace_signal_col")
                prominence = cc.slider("Peak threshold (noise multiples)", 2.0, 12.0, 5.0, 0.5, key="trace_prominence")
                relative_floor = cd.slider("Minimum peak height (% of largest)", 0.1, 5.0, 0.5, 0.1, key="trace_relative_floor")
                points = pd.DataFrame({"time": pd.to_numeric(trace[time_col], errors="coerce"), "signal": pd.to_numeric(trace[signal_col], errors="coerce")}).dropna()
                peaks, trace_summary = analyze_chromatogram(points["time"].to_numpy(), points["signal"].to_numpy(), prominence, relative_height=relative_floor/100)
                st.session_state.latest_chromatogram = {"filename": trace_file.name, "time_column": str(time_col), "signal_column": str(signal_col), "summary": trace_summary, "peaks": peaks}
                st.line_chart(points.set_index("time")["signal"], height=300)
                st.write(f"Detected {len(peaks)} candidate peaks. Estimated baseline: {trace_summary['baseline_estimate']:.4g}; noise: {trace_summary['noise_estimate']:.4g}.")
                if peaks:
                    st.dataframe(pd.DataFrame(peaks), hide_index=True, use_container_width=True)
                    st.download_button("Download candidate peak table", pd.DataFrame(peaks).to_csv(index=False), "candidate_peaks.csv", "text/csv")
                else:
                    st.info("No candidate peaks crossed the current threshold. Adjust the threshold or inspect the signal and CSV columns.")
        except (ValueError, KeyError, TypeError) as exc:
            st.error(f"Could not analyze this chromatogram: {exc}")
    elif st.session_state.get("latest_chromatogram"):
        previous = st.session_state.latest_chromatogram
        st.info(f"Last analyzed file: {previous['filename']} · {previous['summary']['candidate_peak_count']} candidate peaks. Upload a CSV to analyze another trace.")
        if previous.get("peaks"):
            st.dataframe(pd.DataFrame(previous["peaks"]), hide_index=True, use_container_width=True)
    st.caption("Peak areas and widths use a simple constant-baseline/noise heuristic. Check integrations manually; use validated chromatography software for reportable results.")

with tab2:
    st.subheader("System-suitability assessment")
    st.write("Enter system-suitability measurements and thresholds from your approved method or protocol. The example thresholds below are editable placeholders, not universal acceptance criteria.")
    detected = (st.session_state.get("latest_chromatogram") or {}).get("peaks", [])
    peak_pair = None
    if len(detected) >= 2:
        peak_options = {f"Peak {p['peak']} · tR {p['retention_time']:.3f} min": p for p in detected}
        opts = list(peak_options)
        sa, sb = st.columns(2)
        p1_label = sa.selectbox("Earlier peak", opts, index=0, key="sst_peak1")
        p2_label = sb.selectbox("Later peak", opts, index=1, key="sst_peak2")
        peak_pair = (peak_options[p1_label], peak_options[p2_label])
        delta = abs(peak_pair[1]["retention_time"] - peak_pair[0]["retention_time"])
        widths = peak_pair[0]["width_half_height"] + peak_pair[1]["width_half_height"]
        derived_rs = 1.18 * delta / widths if widths > 0 else 0.0
        st.caption(f"Approximate resolution from chromatogram peak widths at half-height: {derived_rs:.3f} (formula Rs ≈ 1.18 ΔtR / (w₀.₅,1 + w₀.₅,2)).")
    else:
        derived_rs = 0.0
        st.info("Analyze a chromatogram with at least two candidate peaks to estimate resolution, or enter the measured resolution below.")
    if peak_pair and peak_pair[0]["width_half_height"] > 0:
        p = peak_pair[0]
        default_plates = 5.54 * (p["retention_time"] / p["width_half_height"]) ** 2
    else:
        default_plates = 2000.0
    pair_signature = ((st.session_state.get("latest_chromatogram") or {}).get("filename"), p1_label if peak_pair else None, p2_label if peak_pair else None)
    if st.session_state.get("sst_pair_signature") != pair_signature:
        st.session_state["sst_rs"] = float(derived_rs)
        st.session_state["sst_plates"] = float(default_plates)
        st.session_state["sst_pair_signature"] = pair_signature
    sm1, sm2, sm3, sm4 = st.columns(4)
    measured_rs = sm1.number_input("Resolution (Rs)", min_value=0.0, value=float(derived_rs), step=0.1, key="sst_rs")
    tailing_value = sm2.number_input("Tailing factor", min_value=0.0, value=1.0, step=0.1, key="sst_tailing")
    plates_value = sm3.number_input("Theoretical plates (N)", min_value=0.0, value=float(default_plates), step=100.0, key="sst_plates")
    area_rsd = sm4.number_input("Peak-area %RSD (replicates)", min_value=0.0, value=1.0, step=0.1, key="sst_area_rsd")
    st.caption("N is estimated from the selected chromatogram peak using 5.54(tR/w₀.₅)² when available. For acceptance, use your method's specified calculation and replicate set.")
    st.markdown("**Acceptance limits (edit to match your method)**")
    ta, tb, tc, td = st.columns(4)
    sst_criteria = {"min_resolution": ta.number_input("Minimum Rs", min_value=0.0, value=1.5, step=0.1, key="sst_min_rs"),
                    "max_tailing": tb.number_input("Maximum tailing", min_value=0.0, value=2.0, step=0.1, key="sst_max_tail"),
                    "min_plates": tc.number_input("Minimum N", min_value=0.0, value=2000.0, step=100.0, key="sst_min_plates"),
                    "max_area_rsd": td.number_input("Maximum area %RSD", min_value=0.0, value=2.0, step=0.1, key="sst_max_rsd")}
    if st.button("Evaluate system suitability"):
        result = system_suitability(measured_rs, tailing_value, plates_value, area_rsd, sst_criteria)
        assessment = {"date": date.today().isoformat(), "resolution": measured_rs, "tailing": tailing_value, "plates": plates_value, "area_rsd": area_rsd, "criteria": sst_criteria, **result}
        st.session_state.suitability_log.append(assessment)
        st.session_state.latest_suitability = assessment
    if st.session_state.get("latest_suitability"):
        result = st.session_state.latest_suitability
        st.success("Pass" if result["overall_pass"] else "Does not meet all entered limits")
        st.json(result["checks"])
    if st.session_state.suitability_log:
        st.dataframe(pd.DataFrame(st.session_state.suitability_log), hide_index=True, use_container_width=True)

with tab3:
    study_locked = bool(st.session_state.runs)
    st.subheader("Compare conventional DoE with adaptive optimization")
    st.write("Run both strategies on the same analyte, factor bounds, analytical targets, and measurement procedure. Log measured responses in each arm; the app will compare observed runs to three passing confirmation injections.")
    study_title = st.text_input("Study title", value="HPLC adaptive-vs-DoE comparison", key="study_title")
    meta1, meta2, meta3 = st.columns(3)
    analyst = meta1.text_input("Analyst", key="analyst")
    instrument = meta2.text_input("Instrument / system ID", key="instrument")
    method_version = meta3.text_input("Method or protocol version", key="method_version")
    criteria_col, plan_col = st.columns([1, 1])
    with criteria_col:
        st.markdown("**Analytical target profile**")
        min_rs = st.number_input("Minimum critical-pair resolution", min_value=0.0, value=1.5, step=0.1, key="min_rs", disabled=study_locked)
        max_tail = st.number_input("Maximum tailing factor", min_value=0.0, value=2.0, step=0.1, key="max_tail", disabled=study_locked)
        max_run = st.number_input("Maximum run time (min)", min_value=0.1, value=10.0, step=0.5, key="max_run", disabled=study_locked)
        max_org = st.number_input("Maximum organic solvent per injection (mL)", min_value=0.0, value=5.0, step=0.5, key="max_org", disabled=study_locked)
    criteria = {"min_resolution": min_rs, "max_tailing": max_tail, "max_run_min": max_run, "max_organic_ml": max_org}
    with plan_col:
        st.markdown("**Conventional comparator**")
        seed = st.number_input("Randomization seed", min_value=0, max_value=2147483647, value=2026, step=1, key="random_seed", disabled=study_locked)
        st.write("Three-factor Box–Behnken response-surface design: 12 edge-midpoint combinations plus 3 center replicates (15 planned runs), randomized using this seed. Map coded factors to the same physical bounds used by the adaptive arm.")
        plan = box_behnken_3factor(int(seed))
        st.download_button("Download 15-run Box–Behnken plan", pd.DataFrame(plan).to_csv(index=False), "box_behnken_3factor_15run.csv", "text/csv")
        st.dataframe(pd.DataFrame(plan), hide_index=True, use_container_width=True)
    st.markdown("**Factor ranges (real settings corresponding to coded −1 and +1)**")
    ra, rb, rc = st.columns(3)
    org_lo = ra.number_input("Organic fraction low (%)", min_value=0.0, max_value=100.0, value=20.0, step=1.0, key="org_lo", disabled=study_locked)
    org_hi = ra.number_input("Organic fraction high (%)", min_value=0.0, max_value=100.0, value=60.0, step=1.0, key="org_hi", disabled=study_locked)
    ph_lo = rb.number_input("pH low", min_value=0.0, max_value=14.0, value=2.5, step=0.1, key="ph_lo", disabled=study_locked)
    ph_hi = rb.number_input("pH high", min_value=0.0, max_value=14.0, value=4.5, step=0.1, key="ph_hi", disabled=study_locked)
    temp_lo = rc.number_input("Temperature low (°C)", min_value=0.0, max_value=150.0, value=25.0, step=1.0, key="temp_lo", disabled=study_locked)
    temp_hi = rc.number_input("Temperature high (°C)", min_value=0.0, max_value=150.0, value=45.0, step=1.0, key="temp_hi", disabled=study_locked)
    if org_lo >= org_hi or ph_lo >= ph_hi or temp_lo >= temp_hi:
        st.error("For each factor, the low setting must be below the high setting.")
    else:
        st.caption(f"Current coding: −1/+1 maps to {org_lo:g}/{org_hi:g}% organic, pH {ph_lo:g}/{ph_hi:g}, and {temp_lo:g}/{temp_hi:g} °C.")
    route = st.radio("Study arm", ["Conventional DoE", "Adaptive optimization"], horizontal=True)
    adaptive_rows = [r for r in st.session_state.runs if r["route"] == "Adaptive optimization"]
    conv_rows = [r for r in st.session_state.runs if r["route"] == "Conventional DoE"]
    suggestion = adaptive_next(adaptive_rows)
    planned_run = plan[len(conv_rows)] if route == "Conventional DoE" and len(conv_rows) < len(plan) else None
    if route == "Conventional DoE" and planned_run:
        plan_org = org_lo + (planned_run["organic"] + 1) * (org_hi - org_lo) / 2
        plan_ph = ph_lo + (planned_run["pH"] + 1) * (ph_hi - ph_lo) / 2
        plan_temp = temp_lo + (planned_run["temperature"] + 1) * (temp_hi - temp_lo) / 2
        st.info(f"Next randomized conventional run {planned_run['run']}/15: {plan_org:g}% organic, pH {plan_ph:g}, column temperature {plan_temp:g} °C.")
    elif route == "Conventional DoE":
        st.info("The 15 planned conventional runs are logged. Any additional runs should be documented as follow-up or confirmation experiments.")
    default = ([planned_run[k] for k in ("organic", "pH", "temperature")] if planned_run else [suggestion.get(k, 0.0) for k in ("organic", "pH", "temperature")])
    defaults_key = (route, tuple(default))
    if st.session_state.get("factor_defaults_key") != defaults_key:
        st.session_state["org"], st.session_state["ph"], st.session_state["temp"] = default
        st.session_state["factor_defaults_key"] = defaults_key
    st.markdown(f"**Record an observed {route.lower()} run**")
    run_date = st.date_input("Run date", value=date.today(), key="run_date")
    with st.form("run_form"):
        levels = [-1.0, -0.5, 0.0, 0.5, 1.0]
        a, b, c = st.columns(3)
        lock_to_plan = route == "Conventional DoE" and planned_run is not None
        organic = a.selectbox("Organic fraction setting", levels, index=levels.index(default[0]) if default[0] in levels else 2, format_func=lambda code: f"{org_lo + (code + 1) * (org_hi - org_lo) / 2:g}%", key="org", disabled=lock_to_plan)
        ph = b.selectbox("Mobile-phase pH setting", levels, index=levels.index(default[1]) if default[1] in levels else 2, format_func=lambda code: f"pH {ph_lo + (code + 1) * (ph_hi - ph_lo) / 2:g}", key="ph", disabled=lock_to_plan)
        temp = c.selectbox("Column temperature setting", levels, index=levels.index(default[2]) if default[2] in levels else 2, format_func=lambda code: f"{temp_lo + (code + 1) * (temp_hi - temp_lo) / 2:g} °C", key="temp", disabled=lock_to_plan)
        a, b, c, dcol = st.columns(4)
        resolution = a.number_input("Critical-pair resolution (Rs)", min_value=0.0, value=0.0, step=0.1)
        tailing = b.number_input("Tailing factor", min_value=0.01, value=1.0, step=0.1)
        run_min = c.number_input("Run time (min)", min_value=0.0, value=10.0, step=0.5)
        organic_ml = dcol.number_input("Organic solvent used (mL)", min_value=0.0, value=0.0, step=0.5)
        confirmation = st.checkbox("Independent confirmation injection at the proposed final settings")
        submitted = st.form_submit_button("Add observed experiment")
        if submitted:
            arm_runs = [r for r in st.session_state.runs if r["route"] == route]
            actual = {"organic_pct": org_lo + (organic + 1) * (org_hi - org_lo) / 2,
                      "pH_actual": ph_lo + (ph + 1) * (ph_hi - ph_lo) / 2,
                      "temperature_c": temp_lo + (temp + 1) * (temp_hi - temp_lo) / 2}
            record = {"run": len(arm_runs)+1, "route": route, "date": run_date.isoformat(), "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
                      "analyst": analyst, "instrument": instrument, "method_version": method_version,
                      "planned_run": planned_run["run"] if route == "Conventional DoE" and planned_run else None,
                      "planned_design_point": planned_run["design_point"] if route == "Conventional DoE" and planned_run else None,
                      "adaptive_recommendation": suggestion if route == "Adaptive optimization" else None,
                      "organic": organic, "pH": ph, "temperature": temp, **actual,
                      "resolution": resolution, "tailing": tailing, "run_min": run_min, "organic_ml": organic_ml, "confirmation": confirmation}
            st.session_state.runs.append(record)
            st.rerun()
    if st.session_state.runs:
        st.dataframe(pd.DataFrame(st.session_state.runs), hide_index=True, use_container_width=True)
        st.download_button("Download combined experiment log (CSV)", pd.DataFrame(st.session_state.runs).to_csv(index=False), "hplc_experiment_log.csv", "text/csv")
        st.subheader("Run-count comparison")
        conv_rows = [r for r in st.session_state.runs if r["route"] == "Conventional DoE"]
        adapt_rows = [r for r in st.session_state.runs if r["route"] == "Adaptive optimization"]
        conv, adap = route_summary(conv_rows, criteria), route_summary(adapt_rows, criteria)
        ca, cb = st.columns(2)
        ca.metric("Conventional DoE", f"{conv['runs']} runs", f"{conv['confirmation_runs']}/3 passing confirmations")
        cb.metric("Adaptive optimization", f"{adap['runs']} runs", f"{adap['confirmation_runs']}/3 passing confirmations")
        if conv["robustness_demonstrated"] and adap["robustness_demonstrated"]:
            reduction = 100 * (conv["runs_to_robustness"] - adap["runs_to_robustness"]) / conv["runs_to_robustness"]
            st.success(f"Observed run-count difference to the defined confirmation criterion: {reduction:.1f}% fewer runs for the adaptive arm." if reduction > 0 else f"Observed run-count difference: {abs(reduction):.1f}% more runs for the adaptive arm." if reduction < 0 else "Both arms reached confirmation in the same number of runs.")
        else:
            st.info("A run-count advantage is not established until both arms have three independent confirmation injections meeting every target.")
        st.subheader("Observed adaptive-arm trade-offs")
        st.dataframe(pd.DataFrame(pareto_rows(adapt_rows)), hide_index=True, use_container_width=True)
    else:
        st.write("Record observations in both study arms to compare their run counts and observed trade-offs.")

    config_keys = ["study_title", "analyst", "instrument", "method_version", "min_rs", "max_tail", "max_run", "max_org", "random_seed", "org_lo", "org_hi", "ph_lo", "ph_hi", "temp_lo", "temp_hi", "analyte_name", "smiles", "descriptor_mw", "descriptor_logp", "descriptor_tpsa", "descriptor_hbd", "descriptor_hba", "descriptor_charge", "descriptor_ionization", "descriptor_smiles_applied", "sst_rs", "sst_tailing", "sst_plates", "sst_area_rsd", "sst_min_rs", "sst_max_tail", "sst_min_plates", "sst_max_rsd"]
    project = {
        "schema_version": 1,
        "study": {"id": st.session_state.study_id, "title": study_title, "created_at_utc": st.session_state.get("study_created_at_utc", datetime.now(timezone.utc).isoformat()), "exported_at_utc": datetime.now(timezone.utc).isoformat()},
        "config": {key: st.session_state.get(key) for key in config_keys},
        "runs": st.session_state.runs,
        "chromatogram_analysis": st.session_state.get("latest_chromatogram"),
        "suitability_log": st.session_state.suitability_log,
        "latest_suitability": st.session_state.get("latest_suitability"),
    }
    safe_name = "".join(char if char.isalnum() or char in "-_" else "_" for char in study_title).strip("_") or "chromatoguide_study"
    st.download_button("Save complete study project (JSON)", json.dumps(project, indent=2, ensure_ascii=False), f"{safe_name}.json", "application/json", help="Includes analyte inputs, fixed study settings, randomized design seed, measured run records, adaptive suggestions, and run metadata.")

with tab4:
    st.subheader("Volume-based solvent indicators")
    col1, col2 = st.columns(2)
    flow = col1.number_input("Flow rate (mL/min)", min_value=0.0, value=1.0, step=0.1)
    duration = col2.number_input("Run time (min)", min_value=0.0, value=10.0, step=0.5)
    col1, col2 = st.columns(2)
    fraction = col1.slider("Organic fraction (0–1)", 0.0, 1.0, 0.5, 0.05)
    solvent = col2.selectbox("Organic solvent", ["Acetonitrile", "Methanol", "Ethanol", "Other / mixture"])
    hazardous = st.slider("Assumed hazardous fraction of organic solvent (user-defined)", 0.0, 1.0, 1.0, 0.05)
    metrics = green_metrics(flow, duration, fraction, solvent, hazardous)
    m1, m2, m3 = st.columns(3)
    m1.metric("Total mobile phase", f"{metrics['total_mobile_phase_ml']} mL")
    m2.metric("Organic solvent", f"{metrics['organic_solvent_ml']} mL")
    m3.metric("Hazard-weighted estimate", f"{metrics['hazardous_solvent_ml_estimate']} mL")
    st.caption(metrics["scope_note"])
    st.write("Use the volume calculator to estimate consumption before a run, then enter its actual organic solvent volume in the experiment log for Pareto comparisons.")

with tab5:
    st.subheader("Adaptive experiment recommendation")
    adaptive_rows = [r for r in st.session_state.runs if r.get("route") == "Adaptive optimization"]
    adaptive_suggestion = adaptive_next(adaptive_rows)
    complete_runs = [r for r in adaptive_rows if all(r.get(k) is not None for k in ("organic", "pH", "temperature", "resolution", "run_min", "organic_ml"))]
    st.metric("Adaptive experiments recorded", len(complete_runs))
    if all(k in adaptive_suggestion for k in ("organic", "pH", "temperature")):
        org_code, ph_code, temp_code = (adaptive_suggestion[k] for k in ("organic", "pH", "temperature"))
        org_actual = float(st.session_state.get("org_lo", 20)) + (org_code + 1) * (float(st.session_state.get("org_hi", 60)) - float(st.session_state.get("org_lo", 20))) / 2
        ph_actual = float(st.session_state.get("ph_lo", 2.5)) + (ph_code + 1) * (float(st.session_state.get("ph_hi", 4.5)) - float(st.session_state.get("ph_lo", 2.5))) / 2
        temp_actual = float(st.session_state.get("temp_lo", 25)) + (temp_code + 1) * (float(st.session_state.get("temp_hi", 45)) - float(st.session_state.get("temp_lo", 25))) / 2
        st.markdown("**Try these settings next**")
        st.dataframe(pd.DataFrame([
            {"Factor": "Organic fraction", "Suggested setting": f"{org_actual:g}%"},
            {"Factor": "Mobile-phase pH", "Suggested setting": f"pH {ph_actual:g}"},
            {"Factor": "Column temperature", "Suggested setting": f"{temp_actual:g} °C"},
        ]), hide_index=True, use_container_width=True)
        st.caption("The displayed values are real settings mapped from the study’s factor ranges.")
        if adaptive_suggestion.get("acquisition") == "space-filling warm-up":
            st.info(f"Exploration run {min(len(complete_runs) + 1, 6)} of 6: this setting helps sample the factor range before the app starts using measured results to guide suggestions.")
        else:
            st.info("This suggestion uses the adaptive-arm results you entered to balance separation, run time, and solvent consumption. Confirm it experimentally.")
        st.write("After running it, record the actual settings and measured responses under **Adaptive optimization** in the AQbD / DoE tab. Those results feed the next suggestion.")
    else:
        st.warning(adaptive_suggestion.get("note", "No unused settings remain in the current factor range. Expand the range or begin a new study."))
    with st.expander("How the suggestions work"):
        st.write("The first six experiments explore different parts of the factor range. After that, the app uses the results you recorded to estimate which untested setting may improve resolution while limiting run time and organic-solvent use. These are experimental suggestions, not guaranteed outcomes.")
    if adaptive_rows:
        def physical_summary(values):
            if not isinstance(values, dict) or not all(k in values for k in ("organic", "pH", "temperature")):
                return "Not recorded"
            o = float(st.session_state.get("org_lo", 20)) + (values["organic"] + 1) * (float(st.session_state.get("org_hi", 60)) - float(st.session_state.get("org_lo", 20))) / 2
            h = float(st.session_state.get("ph_lo", 2.5)) + (values["pH"] + 1) * (float(st.session_state.get("ph_hi", 4.5)) - float(st.session_state.get("ph_lo", 2.5))) / 2
            t = float(st.session_state.get("temp_lo", 25)) + (values["temperature"] + 1) * (float(st.session_state.get("temp_hi", 45)) - float(st.session_state.get("temp_lo", 25))) / 2
            return f"{o:g}% organic; pH {h:g}; {t:g} °C"
        history = [{"Run": r["run"], "Suggested settings": physical_summary(r.get("adaptive_recommendation")), "Run settings": physical_summary(r)} for r in adaptive_rows]
        st.markdown("**Recommendation history**")
        st.dataframe(pd.DataFrame(history), hide_index=True, use_container_width=True)

with tab6:
    st.subheader("Troubleshooting assistant")
    st.write("Select observed symptoms to see checks that can help narrow the cause. These are diagnostic prompts, not an automated root-cause determination.")
    symptoms = ["Low resolution / co-elution", "Low or no retention", "Peak tailing", "High backpressure", "Baseline noise or drift", "Retention-time drift", "Poor repeatability"]
    selected_symptoms = st.multiselect("Observed symptom(s)", symptoms)
    for item in troubleshooting_guidance(selected_symptoms):
        with st.expander(item["symptom"], expanded=True):
            st.write(item["guidance"])
            st.caption(item["interpretation"])

with tab7:
    st.subheader("Analytical R&D workspace")
    st.write("Study overview across analyte characterization, chromatograms, suitability checks, DoE, green metrics, and adaptive recommendations.")
    conv_rows = [r for r in st.session_state.runs if r.get("route") == "Conventional DoE"]
    adapt_rows = [r for r in st.session_state.runs if r.get("route") == "Adaptive optimization"]
    chrom_state = st.session_state.get("latest_chromatogram")
    suitability = st.session_state.get("latest_suitability")
    da, db, dc, dd = st.columns(4)
    da.metric("Conventional runs", len(conv_rows))
    db.metric("Adaptive runs", len(adapt_rows))
    dc.metric("Latest chromatogram peaks", chrom_state["summary"]["candidate_peak_count"] if chrom_state else "Not analyzed")
    dd.metric("Latest suitability", ("Pass" if suitability["overall_pass"] else "Review") if suitability else "Not assessed")
    st.markdown("**Current stage status**")
    status_rows = [
        {"Stage": "Analyte chemistry", "Status": "Entered" if st.session_state.get("analyte_name") or st.session_state.get("smiles") else "Ready"},
        {"Stage": "Chromatogram analyzer", "Status": "Analyzed" if chrom_state else "Ready"},
        {"Stage": "System suitability", "Status": "Assessed" if suitability else "Ready"},
        {"Stage": "AQbD / DoE", "Status": f"{len(st.session_state.runs)} runs logged"},
        {"Stage": "Green method", "Status": "Metrics calculator available"},
        {"Stage": "Adaptive recommendation", "Status": "Available"},
        {"Stage": "Troubleshooting", "Status": "Available"},
        {"Stage": "R&D workspace", "Status": "Active"},
    ]
    st.dataframe(pd.DataFrame(status_rows), hide_index=True, use_container_width=True)
    if st.session_state.runs:
        st.info("Save the complete study JSON from the AQbD / DoE tab to preserve current records and settings.")

st.divider()
st.caption("Research prototype · Confirm method recommendations experimentally.")
