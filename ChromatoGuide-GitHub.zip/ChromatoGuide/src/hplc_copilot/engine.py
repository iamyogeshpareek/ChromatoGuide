"""Transparent, deliberately conservative chemistry and experiment heuristics."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

import numpy as np


@dataclass
class Descriptors:
    molecular_weight: float | None = None
    clogp: float | None = None
    tpsa: float | None = None
    hbd: int | None = None
    hba: int | None = None
    formal_charge: int | None = None


def from_smiles(smiles: str) -> tuple[Descriptors | None, str | None]:
    """Calculate 2D descriptors when RDKit is installed; no pKa inference."""
    try:
        from rdkit import Chem
        from rdkit.Chem import Descriptors as D, rdMolDescriptors
    except ImportError:
        return None, "RDKit is optional. Install it to calculate descriptors from SMILES; you can enter descriptors manually."
    mol = Chem.MolFromSmiles(smiles)
    if mol is None:
        return None, "Could not parse this SMILES. Check the structure or enter descriptors manually."
    return Descriptors(
        molecular_weight=round(D.MolWt(mol), 2),
        clogp=round(D.MolLogP(mol), 2),
        tpsa=round(rdMolDescriptors.CalcTPSA(mol), 2),
        hbd=int(rdMolDescriptors.CalcNumHBD(mol)),
        hba=int(rdMolDescriptors.CalcNumHBA(mol)),
        formal_charge=int(Chem.GetFormalCharge(mol)),
    ), None


def recommend(d: Descriptors, pka_class: str) -> list[dict[str, Any]]:
    """Rank modes using broad descriptors; rankings are starting hypotheses."""
    polarity = d.tpsa if d.tpsa is not None else 50
    logp = d.clogp if d.clogp is not None else 1
    charge = d.formal_charge if d.formal_charge is not None else 0
    highly_polar = polarity >= 90
    low_hydrophobicity = logp < 1
    ionizable = pka_class != "Unknown / not supplied" or charge != 0
    scores = {"Reversed-phase (RP)": 2, "HILIC": 1, "Ion-exchange": 0, "Mixed-mode": 1}
    reasons: dict[str, list[str]] = {k: [] for k in scores}
    if low_hydrophobicity or highly_polar:
        scores["HILIC"] += 3
        reasons["HILIC"].append("High polarity or low estimated hydrophobicity may limit retention in conventional RP.")
        scores["Mixed-mode"] += 2
        reasons["Mixed-mode"].append("Combining hydrophobic and polar/ionic interactions may be useful if single-mode retention is inadequate.")
    else:
        scores["Reversed-phase (RP)"] += 3
        reasons["Reversed-phase (RP)"].append("Descriptor profile is compatible with investigating hydrophobic partitioning on RP phases.")
    if ionizable:
        scores["Ion-exchange"] += 3
        scores["Mixed-mode"] += 2
        reasons["Ion-exchange"].append("Ionization is indicated or specified; charge-selective retention may be worth screening.")
        reasons["Reversed-phase (RP)"].append("For ionizable analytes, retention and selectivity can depend strongly on mobile-phase pH and buffer conditions.")
    if not reasons["Reversed-phase (RP)"]:
        reasons["Reversed-phase (RP)"].append("RP is a common baseline screen; retention must be confirmed experimentally.")
    if not reasons["HILIC"]:
        reasons["HILIC"].append("Consider as an alternative screen if RP gives weak retention or selectivity.")
    if not reasons["Ion-exchange"]:
        reasons["Ion-exchange"].append("Prioritize only when the analyte is charged under the selected mobile-phase conditions.")
    if not reasons["Mixed-mode"]:
        reasons["Mixed-mode"].append("A useful fallback when single-mode selectivity or retention is insufficient.")
    columns = {
        "Reversed-phase (RP)": [("C18", "Broad hydrophobic retention baseline."), ("Polar-embedded RP", "May improve compatibility for polar analytes and alter selectivity."), ("Phenyl-hexyl", "Offers aromatic and shape-related selectivity alongside hydrophobic retention.")],
        "HILIC": [("Amide-HILIC", "Polar stationary phase suitable for screening polar analytes."), ("Zwitterionic HILIC", "Mixed ionic and partitioning interactions; retention may be pH/salt-sensitive."), ("Bare silica HILIC", "Strong polar interactions; surface ionization and pH require attention.")],
        "Ion-exchange": [("Strong cation exchange (SCX)", "Investigate for positively charged analytes."), ("Strong anion exchange (SAX)", "Investigate for negatively charged analytes."), ("Weak ion-exchange phase", "Offers pH-responsive surface charge and selectivity.")],
        "Mixed-mode": [("RP / cation-exchange", "Combines hydrophobic retention with cation-selective interactions."), ("RP / anion-exchange", "Combines hydrophobic retention with anion-selective interactions."), ("Polar-embedded RP", "Practical mixed-polarity RP screen where ionic charge is uncertain.")],
    }
    ranked = sorted(scores, key=lambda k: scores[k], reverse=True)
    return [{"mode": mode, "score": scores[mode], "rationale": reasons[mode], "columns": columns[mode]} for mode in ranked]


FACTOR_KEYS = ("organic", "pH", "temperature")


def box_behnken_3factor(seed: int = 2026) -> list[dict[str, float | int]]:
    """Randomized 3-factor Box–Behnken plan with three center replicates."""
    points = []
    for fixed in range(3):
        varying = [i for i in range(3) if i != fixed]
        for a, b in [(-1., -1.), (-1., 1.), (1., -1.), (1., 1.)]:
            point = [0., 0., 0.]
            point[varying[0]], point[varying[1]] = a, b
            points.append(point)
    points.extend([[0., 0., 0.]] * 3)
    order = np.random.default_rng(seed).permutation(len(points))
    return [{"run": i + 1, "design_point": int(order[i]) + 1, **dict(zip(FACTOR_KEYS, points[order[i]]))} for i in range(len(points))]


def _gp_predict(x: np.ndarray, y: np.ndarray, candidates: np.ndarray, length: float = .8) -> tuple[np.ndarray, np.ndarray]:
    """Small fixed-kernel GP with standardized outputs and a modest noise term."""
    scale = np.std(y) or 1.0
    mean_y = np.mean(y)
    ys = (y - mean_y) / scale
    def kernel(a: np.ndarray, b: np.ndarray) -> np.ndarray:
        return np.exp(-.5 * np.sum((a[:, None, :] - b[None, :, :]) ** 2, axis=2) / (length ** 2))
    k = kernel(x, x) + np.eye(len(x)) * .06
    ks = kernel(candidates, x)
    alpha = np.linalg.solve(k, ys)
    means = ks @ alpha
    variance = np.maximum(1.0 - np.sum(ks * np.linalg.solve(k, ks.T).T, axis=1), 1e-6)
    return means * scale + mean_y, np.sqrt(variance) * scale


def adaptive_next(observations: list[dict[str, Any]]) -> dict[str, Any]:
    """Suggest via GP random-scalarization expected improvement after warm-up."""
    complete = [r for r in observations if all(r.get(k) is not None for k in (*FACTOR_KEYS, "resolution", "run_min", "organic_ml"))]
    levels = np.linspace(-1., 1., 5)
    candidates = np.array([(a, b, c) for a in levels for b in levels for c in levels])
    used = {tuple(float(r[k]) for k in FACTOR_KEYS) for r in observations}
    candidates = np.array([p for p in candidates if tuple(p) not in used])
    if not len(candidates):
        return {"note": "All points in the coded candidate grid are used. Expand factor bounds or redesign the study."}
    x = np.array([[float(r[k]) for k in FACTOR_KEYS] for r in complete])
    distinct = len({tuple(row) for row in x})
    if distinct < 6:
        if len(x):
            scores = np.min(np.sum((candidates[:, None, :] - x[None, :, :]) ** 2, axis=2), axis=1)
        else:
            scores = -np.sum(candidates ** 2, axis=1)
        chosen = candidates[int(np.argmax(scores))]
        acquisition = "space-filling warm-up"
        note = f"Warm-up: space-filling point; {distinct}/6 distinct complete runs available before response models are used."
    else:
        ys = [np.array([float(r[k]) for r in complete]) for k in ("resolution", "run_min", "organic_ml")]
        means, stds = [], []
        for y in ys:
            mu, sd = _gp_predict(x, y, candidates)
            means.append(mu)
            stds.append(sd)
        means, stds = np.column_stack(means), np.column_stack(stds)
        oriented = np.column_stack((ys[0], -ys[1], -ys[2]))
        lo = oriented.min(axis=0)
        span = np.maximum(oriented.max(axis=0) - lo, 1e-9)
        pred_mu = (np.column_stack((means[:, 0], -means[:, 1], -means[:, 2])) - lo) / span
        pred_sd = stds / span
        observed_utility = (oriented - lo) / span
        rng = np.random.default_rng(17 + len(complete))
        weights = rng.dirichlet(np.ones(3), size=32)
        draws = rng.normal(pred_mu[:, None, :], pred_sd[:, None, :], size=(len(candidates), 64, 3))
        utility = np.einsum("csd,wd->csw", draws, weights)
        incumbents = np.max(observed_utility @ weights.T, axis=0)
        ei = np.maximum(utility - incumbents[None, None, :], 0).mean(axis=1).mean(axis=1)
        chosen = candidates[int(np.argmax(ei))]
        acquisition = "GP random-scalarization expected improvement"
        note = "Gaussian-process surrogate and random-scalarization expected improvement across resolution, runtime, and organic-solvent use. Predictions are exploratory; review fit quality and confirm with experiments."
    return {**dict(zip(FACTOR_KEYS, [float(v) for v in chosen])), "acquisition": acquisition, "note": note}


def criteria_met(row: dict[str, Any], criteria: dict[str, float]) -> bool:
    """Check one run against user-defined method acceptance targets."""
    return (row.get("resolution", -np.inf) >= criteria["min_resolution"] and
            row.get("tailing", np.inf) <= criteria["max_tailing"] and
            row.get("run_min", np.inf) <= criteria["max_run_min"] and
            row.get("organic_ml", np.inf) <= criteria["max_organic_ml"])


def route_summary(rows: list[dict[str, Any]], criteria: dict[str, float]) -> dict[str, Any]:
    """Count runs to three independent, criteria-passing confirmation injections."""
    eligible = [r for r in rows if criteria_met(r, criteria)]
    groups: dict[tuple[float, ...], list[dict[str, Any]]] = {}
    for row in eligible:
        if row.get("confirmation", False):
            key = tuple(float(row[k]) for k in FACTOR_KEYS)
            groups.setdefault(key, []).append(row)
    confirmation_group = max(groups.values(), key=len, default=[])
    reached = len(confirmation_group) >= 3
    return {"runs": len(rows), "criteria_met_runs": len(eligible), "confirmation_runs": len(confirmation_group), "robustness_demonstrated": reached, "runs_to_robustness": max(r["run"] for r in confirmation_group) if reached else None}


def analyze_chromatogram(time: np.ndarray, signal: np.ndarray, prominence_sigma: float = 5.0, min_distance: int = 5, relative_height: float = .005) -> tuple[list[dict[str, float | int]], dict[str, float]]:
    """Find candidate local peaks and estimate FWHM/area from a single trace.

    This simple baseline/noise heuristic is intended for screening and review,
    not validated integration or regulated reporting.
    """
    x = np.asarray(time, dtype=float)
    y = np.asarray(signal, dtype=float)
    if x.ndim != 1 or y.ndim != 1 or len(x) != len(y) or len(x) < 5:
        raise ValueError("Time and signal must be equal-length one-dimensional columns with at least five rows.")
    if not np.all(np.isfinite(x)) or not np.all(np.isfinite(y)) or np.any(np.diff(x) <= 0):
        raise ValueError("Time and signal must be finite, and time must increase strictly.")
    baseline = float(np.quantile(y, .05))
    corrected = y - baseline
    differences = np.diff(y)
    noise = float(np.median(np.abs(differences - np.median(differences))) / .6745 / np.sqrt(2))
    threshold = max(noise * prominence_sigma, float(np.max(corrected)) * relative_height, np.finfo(float).eps)
    local_maxima = np.flatnonzero((corrected[1:-1] >= corrected[:-2]) & (corrected[1:-1] > corrected[2:]) & (corrected[1:-1] >= threshold)) + 1
    window = max(min_distance * 5, 20)
    raw = []
    prominences: dict[int, float] = {}
    for idx in local_maxima:
        left_min = float(np.min(corrected[max(0, idx-window):idx])) if idx > 0 else float(corrected[idx])
        right_min = float(np.min(corrected[idx+1:min(len(y), idx+window+1)])) if idx < len(y)-1 else float(corrected[idx])
        prominence = float(corrected[idx] - max(left_min, right_min))
        if prominence >= threshold:
            raw.append(int(idx))
            prominences[int(idx)] = prominence
    picked: list[int] = []
    for idx in sorted(raw, key=lambda i: corrected[i], reverse=True):
        if all(abs(idx - kept) >= min_distance for kept in picked):
            picked.append(idx)
    picked.sort()
    results = []
    for rank, idx in enumerate(picked, start=1):
        height = float(corrected[idx])
        half = height / 2
        left = idx
        while left > 0 and corrected[left] > half:
            left -= 1
        right = idx
        while right < len(y)-1 and corrected[right] > half:
            right += 1
        # Interpolate half-height crossings.
        lx = x[left]
        if left < idx and corrected[left+1] != corrected[left]:
            lx += (half-corrected[left]) * (x[left+1]-x[left]) / (corrected[left+1]-corrected[left])
        rx = x[right]
        if right > idx and corrected[right-1] != corrected[right]:
            rx = x[right-1] + (half-corrected[right-1]) * (x[right]-x[right-1]) / (corrected[right]-corrected[right-1])
        if rank > 1:
            previous_idx = picked[rank - 2]
            lo = previous_idx + int(np.argmin(corrected[previous_idx:idx]))
        else:
            crossings = np.flatnonzero(corrected[:idx] <= max(noise * 2, threshold * .1))
            lo = int(crossings[-1]) if len(crossings) else 0
        if rank < len(picked):
            next_idx = picked[rank]
            hi = idx + int(np.argmin(corrected[idx:next_idx+1]))
        else:
            crossings = np.flatnonzero(corrected[idx+1:] <= max(noise * 2, threshold * .1))
            hi = idx + 1 + int(crossings[0]) if len(crossings) else len(y)-1
        integrate = np.trapezoid if hasattr(np, "trapezoid") else np.trapz
        area = float(integrate(np.maximum(corrected[lo:hi+1], 0), x[lo:hi+1])) if hi > lo else 0.0
        results.append({"peak": rank, "index": int(idx), "retention_time": float(x[idx]), "height": height, "prominence": prominences[idx], "width_half_height": float(max(0, rx-lx)), "area_estimate": area})
    return results, {"baseline_estimate": baseline, "noise_estimate": noise, "threshold": threshold, "candidate_peak_count": len(results)}


def system_suitability(resolution: float, tailing: float, plates: float, area_rsd: float, criteria: dict[str, float]) -> dict[str, Any]:
    checks = {
        "resolution": resolution >= criteria["min_resolution"],
        "tailing": tailing <= criteria["max_tailing"],
        "theoretical_plates": plates >= criteria["min_plates"],
        "area_rsd": area_rsd <= criteria["max_area_rsd"],
    }
    return {"checks": checks, "overall_pass": all(checks.values())}


def troubleshooting_guidance(symptoms: list[str]) -> list[dict[str, str]]:
    guidance = {
        "Low resolution / co-elution": ["Check retention and selectivity separately; adjust one method variable at a time or design a focused DoE.", "Review pH/ionization, organic fraction, column chemistry, and gradient slope; confirm the critical pair by standards."],
        "Low or no retention": ["Verify analyte identity, injection solvent strength, and mobile-phase pH/ionization.", "Screen a weaker RP mobile phase or consider HILIC, ion-exchange, or mixed-mode based on analyte chemistry."],
        "Peak tailing": ["Check sample overload, extra-column dead volume, active sites, column condition, and pH/buffer compatibility.", "Compare injection load and a fresh/appropriate column before changing multiple conditions."],
        "High backpressure": ["Check for blocked frits, particulate contamination, precipitated buffer, and temperature/viscosity effects.", "Follow instrument and column pressure limits; isolate the restriction using the instrument's approved procedure."],
        "Baseline noise or drift": ["Check detector lamp/stability, bubbles, leaks, mobile-phase preparation, equilibration, and gradient mixing.", "Run a blank and inspect pressure and detector signals before attributing the issue to the column or analyte."],
        "Retention-time drift": ["Check flow delivery, mobile-phase composition/pH, equilibration, column temperature, and leaks.", "Compare bracketed standards and pump pressure to distinguish system drift from sample effects."],
        "Poor repeatability": ["Review injection precision, sample preparation, vial position, autosampler wash, and integration settings.", "Use replicate standards and inspect raw chromatograms before pooling results."],
    }
    return [{"symptom": symptom, "guidance": " ".join(guidance[symptom]), "interpretation": "Troubleshooting prompts are hypotheses; confirm the cause with blanks, standards, system checks, and controlled experiments."} for symptom in symptoms if symptom in guidance]


def green_metrics(flow_ml_min: float, run_min: float, organic_fraction: float, solvent: str, hazardous_fraction: float = 1.0) -> dict[str, float | str]:
    total = max(0, flow_ml_min * run_min)
    organic = total * max(0, min(1, organic_fraction))
    return {"total_mobile_phase_ml": round(total, 2), "organic_solvent_ml": round(organic, 2), "aqueous_mobile_phase_ml": round(total-organic, 2), "hazardous_solvent_ml_estimate": round(organic * max(0, min(1, hazardous_fraction)), 2), "solvent": solvent, "scope_note": "Volume-based screening indicators only; not AGREE, GAPI, or a life-cycle assessment."}


def pareto_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return observed rows not dominated on resolution, runtime, and organic use."""
    valid = [r for r in rows if all(r.get(k) is not None for k in ("resolution", "run_min", "organic_ml"))]
    result = []
    for row in valid:
        dominated = any((other["resolution"] >= row["resolution"] and other["run_min"] <= row["run_min"] and other["organic_ml"] <= row["organic_ml"] and (other["resolution"] > row["resolution"] or other["run_min"] < row["run_min"] or other["organic_ml"] < row["organic_ml"])) for other in valid if other is not row)
        if not dominated:
            result.append(row)
    return result
